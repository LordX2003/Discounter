function calculateDiscountPercentage() {
    var originalPrice = parseFloat(document.getElementById("originalPrice").value);
    var discountedPrice = parseFloat(document.getElementById("discountedPrice").value);
    
    if (isNaN(originalPrice) || isNaN(discountedPrice)) {
        alert("يرجى إدخال قيمة صحيحة.");
        return;
    }
    
    var discountPercentage = ((originalPrice - discountedPrice) / originalPrice) * 100;
    
    document.getElementById("discountPercentage").innerText = "نسبة الخصم: " + discountPercentage.toFixed(2) + "%";
}